data is stored in 'Data/RicePhoneBackUp/' directory. There is one folder for each particvipants.  That folder contains a folder called 'files'. 'files' contains two folders a) cerebralcortex and b) raW.

Just change basedir variable.

